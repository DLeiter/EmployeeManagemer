﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManager.Models
{
	public enum ActionEnum
	{
		Create,
		Update,
		Delete
	}
}
